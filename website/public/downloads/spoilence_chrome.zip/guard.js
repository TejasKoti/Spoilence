setTimeout(()=>{let t=document.documentElement;t&&!t.hasAttribute("data-ss-ready")&&t.setAttribute("data-ss-ready","degraded")},5e3);
